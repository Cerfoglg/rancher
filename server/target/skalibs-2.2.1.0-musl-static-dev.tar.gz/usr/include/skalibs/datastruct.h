/* ISC license. */

#ifndef DATASTRUCT_H
#define DATASTRUCT_H

#include <skalibs/genset.h>
#include <skalibs/gensetdyn.h>
#include <skalibs/avlnode.h>
#include <skalibs/avltree.h>
#include <skalibs/avltreen.h>

#endif
